﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using Matrix.Financials.Test.Security;

namespace Matrix.Financials.Test.Helpers
{
    public static class ServiceHelper
    {

        public static TReturn UseService<TChannel, TReturn>(Func<TChannel, TReturn> code)
        {
            var channelFactory = GetCachedFatory<TChannel>();
            TChannel channel = channelFactory.CreateChannel();
            bool error = true;
            try
            {
                var context = new OperationContext((IContextChannel)channel);
                using (new OperationContextScope(context))
                {
                    context.OutgoingMessageProperties[HttpRequestMessageProperty.Name] = SecurityManager.Current.HttpProp;

                    TReturn result = code(channel);
                    ((IClientChannel) channel).Close();
                    error = false;
                    return result;
                }
            }
            finally
            {
                if (error)
                {
                    ((IClientChannel)channel).Abort();
                }
            }
        }

        private static ChannelFactory<T> GetCachedFatory<T>()
        {
            return new ChannelFactory<T>("*");
        }
    }
}
