﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using IdentityModel.Client;

namespace Matrix.GetSTSToken
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            var result = GetToken(
                tbStsUrl.Text + "/connect/token",
                tbUsername.Text,
                tbPassword.Text);
            tbHeader.Text = "Authorization: Bearer " + result.AccessToken;
        }

        private TokenResponse GetToken(string tokenEndpoint, string userName, string password)
        {            
            var oauth2Client = new TokenClient(tokenEndpoint, "roclient", "secret");
            var tokenResponse = oauth2Client.RequestResourceOwnerPasswordAsync(userName, password, "openid profile email matrix_account").Result;
            return tokenResponse;
        }
    }
}
