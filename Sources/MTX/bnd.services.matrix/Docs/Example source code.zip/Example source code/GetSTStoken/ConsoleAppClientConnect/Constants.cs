﻿namespace ConsoleAppClientConnect
{
    public static class Constants
    {
        public const string BaseAddress = "https://bnd-app-02/core";

        //public const string BaseAddress = "https://localhost:44300/core";

        public const string TokenEndpoint = BaseAddress + "/connect/token";
    }
}
