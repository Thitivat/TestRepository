﻿using System;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Channels;
using IdentityModel.Client;
using Matrix.Financials.Core.ClientAPI.ApprovalService;

namespace ConsoleAppClientConnect
{
    class Program
    {
        static void Main(string[] args)
        {
            var response = GetToken();
            CallWcf(response);
        }

        static void CallWcf(TokenResponse token)
        {
            var httpRequestProperty = new HttpRequestMessageProperty();
            httpRequestProperty.Headers[HttpRequestHeader.Authorization] = string.Format("Bearer {0}", token.AccessToken);
            var client = new ApprovalServiceClient();

            var context = new OperationContext(client.InnerChannel);

            using (new OperationContextScope(context))
            {
                context.OutgoingMessageProperties[HttpRequestMessageProperty.Name] = httpRequestProperty;

                var res = client.Approve(Guid.NewGuid(), 102, Guid.NewGuid(), "Demo");

                Console.WriteLine($"WCF Approve() Call: {res}");
            }

            Console.ReadLine();
        }

        static TokenResponse GetToken()
        {
            var oauth2Client = new TokenClient(Constants.TokenEndpoint, "roclient", "secret");
            var tokenResponse = oauth2Client.RequestResourceOwnerPasswordAsync("diddi", "Didman123", "openid profile email matrix_account").Result;
            return tokenResponse;
        }

    }
}
